﻿const openButtons = document.querySelectorAll('[data-modal-target]')
const closeButtons = document.querySelectorAll('[data-close-button]')
const overlay = document.getElementById('overlay')

openButtons.forEach(button => { 
button.addEventListener('click', () => {
const modal = document.querySelector(button.dataset.modalTarget) 
openModal(modal) 
})
})
overlay.addEventListener('click', () =>{ 
const modals = document.querySelectorAll('.modal.active')
modals.forEach(modal => {
closeModal(modal)
})
})
      
closeButtons.forEach(button => {
button.addEventListener('click', () => {
const modal = button.closest('.modal') 
closeModal(modal)
})
})
function openModal(modal) {
if (modal == null) return 
modal.classList.add('active')
overlay.classList.add('active')
}

function closeModal(modal) {
if (modal == null) return
modal.classList.remove('active') 
overlay.classList.remove('active')
}

fetch('https://fakestoreapi.com/products').then((data) =>{
return data.json();
}).then((completedata) =>{
let data1="";
completedata.map((values) =>{
data1+=`<div class="card">
<h1 class="title">${values.title}</h1>
<img src="${values.image}" class="img">
<p class="description">${values.description}</p>
<p class="category">${values.category}</p>
<p class="price">Price:${values.price}</p>
</div>`
});
document.getElementById("cards").innerHTML=data1;
}).catch((err) =>{
console.log(err);
})

const button = document.querySelector(".modal-body button");
const jokeDiv = document.querySelector(".modal-body .joke p");

document.addEventListener("DOMContentLoaded", getJoke);

button.addEventListener("click", getJoke);

async function getJoke() {
  const jokeData = await fetch("https://api.chucknorris.io/jokes/random", {
    headers: {
      Accept: "application/json"
    }
  });
  const jokeObj = await jokeData.json();
  jokeDiv.innerHTML = jokeObj.value;
  console.log(jokeData);
}
